import { ShaderChunk } from "three";

import cascadedFadedLights from "./shaders/cascadedFadedLights.glsl?raw";
import cascadedLights from "./shaders/cascadedLights.glsl?raw";
import cascadedLightsWithoutShadows from "./shaders/cascadedLightsWithoutShadows.glsl?raw";
import defaultLights from "./shaders/defaultLights.glsl?raw";
import nonShadowCastingLights from "./shaders/nonShadowCastingLights.glsl?raw";

const uniforms = /* glsl */ `
  #include <lights_pars_begin>

  #ifdef CSM
    uniform vec2 csmCascades[CSM_CASCADE_COUNT];
    uniform float csmNear;
    uniform float csmFar;
  #endif // CSM
`;

function body(shader: string): string {
  return shader.replace(/^\s*void\s+\w+\s*\(\s*\)\s*/m, "");
}

const directionalLights = /*#__PURE__*/ (() => /* glsl */ `
  #if NUM_DIR_LIGHTS > 0 && defined(RE_Direct)
    DirectionalLight directionalLight;
    #if defined(USE_SHADOWMAP) && NUM_DIR_LIGHT_SHADOWS > 0
      DirectionalLightShadow directionalLightShadow;
    #endif

    #ifdef CSM
      #ifdef USE_SHADOWMAP
        #ifdef CSM_FADE
          ${body(cascadedFadedLights)}
        #else
          ${body(cascadedLights)}
        #endif // CSM_FADE
      #elif NUM_DIR_LIGHT_SHADOWS > 0
        ${body(cascadedLightsWithoutShadows)}
      #endif // USE_SHADOWMAP

      #if NUM_DIR_LIGHTS > NUM_DIR_LIGHT_SHADOWS
        ${body(nonShadowCastingLights)}
      #endif
    #else
      ${body(defaultLights)}
    #endif // CSM
  #endif // NUM_DIR_LIGHTS > 0 && defined(RE_Direct)
`)();

type ReplaceRangeParams = {
  source: string;
  startLine: string;
  endLine: string;
  replacement: string;
};

function findAndReplace({
  source,
  startLine,
  endLine,
  replacement,
}: ReplaceRangeParams): string {
  const startText = `\n${startLine}\n`;
  const startIndex = source.indexOf(startText);
  if (startIndex < 0) {
    return source;
  }
  const endText = `\n${endLine}\n`;
  const endIndex = source.indexOf(endText, startIndex + startText.length);
  if (endIndex < 0) {
    return source;
  }
  return (
    source.slice(0, startIndex + 1) +
    replacement +
    source.slice(endIndex + endText.length - 1)
  );
}

export function createFragmentShader(fragmentShader: string): string {
  return fragmentShader
    .replace("#include <lights_pars_begin>", uniforms)
    .replace(
      "#include <lights_fragment_begin>",
      findAndReplace({
        source: ShaderChunk.lights_fragment_begin,
        startLine: "#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )",
        endLine: "#endif",
        replacement: directionalLights,
      }),
    );
}
