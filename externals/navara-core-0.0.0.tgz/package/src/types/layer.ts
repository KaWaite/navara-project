export type LayerId = string;
